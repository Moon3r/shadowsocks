<?php
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','toor');
//database name
define('DB_NAME','myblog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','SsRwMVIAw(O#JpBTCEGZiZ&b#VPKu1XOeb6943aa3cf63d2256c51e0f15bde83c');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_2wIK9TritWFsvSBnNJQXxBuiH3xeaWtQ');
