	<?php
		if(!defined('EMLOG_ROOT')) {exit('error!');}
		include View::getView('./content/templates/Life/header');
	?>
	<span>mail:kkzeroc@163.com</span>
	<span>QQ:123456</span>

