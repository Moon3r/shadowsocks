<?php
/*

    Template Name:Life
    Description:极简主义者
    Version:1.1
    Author:Secret
    Author Url:http://blog.myiooc.cn
    Sidebar Amount:0
    
 */
 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- 文章内容开始 -->
<content>
<div class="main">
	<div class="article">
		<div class="article-title">
			<?php echo $log_title; ?>
		</div>
		<small class="article-time">发表于 <?php echo gmdate('Y-n-j', $date); ?> | <span class="baiduapi" title="<?php echo log_url() ?>"></span> | <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
		</small>
		<div class="article-content">
			<?php echo $log_content; ?>
		</div>
		<div class="post-footer">
			<div class="post-tags">
				<?php blog_tag($logid); ?>
			</div>
			<div class="post-nav">
				<?php neighbor_log($neighborLog); ?>
			</div>
		</div>
	</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</content>
<div class="toc"></div>
<?php
 include View::getView('footer');
?>