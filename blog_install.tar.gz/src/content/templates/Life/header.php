<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $site_title; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="apple-mobile-web-app-capable" content="yes"/>
	<meta name="author" content="<?php echo $site_title; ?>"/>
	<meta name="msapplication-TileColor" content="#3ac19f"/>
	<!-- 请将站点icon和图表放到站点根目录 -->
	<link rel="shortcut icon" type="image/ico" href="<?php echo BLOG_URL; ?>favicon.ico" />
	<meta name="msapplication-TileImage" content="<?php echo BLOG_URL; ?>icon.png"/>
	<meta name="apple-mobile-web-app-title" content="<?php echo $site_title; ?>">
	<meta name="Keywords" content="<?php echo $site_key; ?>
	"/>
	<meta name="Description" content="<?php echo $site_description; ?>
	"/>
	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/style.css">
	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/iconfont.css">
	<?php doAction('index_head'); ?>
</head>
<body>
<header>
<div class="main">
	<div class="intro">
		<!-- 调用后台上传的头像，请到后台上传 -->
		<img src="<?php blogger_photo();?>" class="intro-logo"/>
		<span class="intro-sitename"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?>
		</a></span>
		<span class="intro-siteinfo"><?php echo $bloginfo; ?>
		</span>
		<span class="social">
		<!-- 
			联系方式中不需要的链接可直接删除
		--><!--
		<!-- 调用QQ链接，请到 http://shang.qq.com/ 申请
		<a href="#" target="_blank"><i class="iconfont icon-qq"></i></a>
		 邮箱链接，格式:mailto:mail@mail.com
		<a href="#" target="_blank"><i class="iconfont icon-mail"></i></a>
		 微博链接,格式:https://www.weibo.com/weiboid
		<a href="#" target="_blank"><i class="iconfont icon-weibo"></i></a>
		 GitHub链接，格式:https://www.github.com/yourid 
		<a href="#" target="_blank"><i class="iconfont icon-github"></i></a>
		 Coding链接，格式:https://coding.net/u/yourid 
		<a href="#" target="_blank"><i class="iconfont icon-coding"></i></a>
		</span> -->
	</div>
	<nav>
	<div class="collapse">
		<i class="iconfont icon-menu"></i>
	</div>
	<ul class="bar">
		<?php blog_navi();?>
	</ul>
	</nav>
</div>
</header>
